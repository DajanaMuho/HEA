<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi </title>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>
			<section class="caption">
				<h2 class="caption" style="text-align: center">Na kontaktoni </h2>
			</section>
	</section>
<section class="wrapper">
<i class="fa fa-phone" style="font-size:30px"></i>  +355 68 59 04 225<br>
<i class="material-icons" style="font-size:30px">email</i>  <a href:"mailto:dajana.muho@fshnstudent.info">dajana.muho@fshnstudent.info</a><br><br><br>
</section>
<!--
IMPORTIMI I GOOGLE MAP -->

<section class="wrapper">
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d999.7331313950157!2d19.816792942853223!3d41.33464751254773!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1484691797001" width="800" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</section><br><br>

<section class="wrapper">
	<form method="POST">
		<label for="name">Emri juaj:</label><br/>
		<input id="name" class="input" name="name" type="text" value="" size="30" required="true" /><br />
		<label for="email" required="true" >Email juaj:</label><br />
		<input id="email" class="input" name="email" type="email" value="" size="30" required="true" /><br />
		<label for="message" required="true" >Mesazhi juaj:</label><br />
		<textarea id="message" class="input" name="message" rows="7" cols="30"></textarea><br />
		<button name="send" type="submit" type="button" class="btn btn-primary btn-md"/>Dërgo Email</button>
	</form>
</section><br><br>
<?php
						if(isset($_POST['send']))
						{
								include 'includes/config.php';

								$name = strip_tags($_POST['name']);
								$mail = strip_tags($_POST['email']);
								$message = strip_tags($_POST['message']);

								$qry = "INSERT INTO kontakt (k_msg, k_mail, k_name) VALUES('$message','$mail','$name')";
								$result = $conn->query($qry);

								if($result == TRUE)
								{
									echo "<script type = \"text/javascript\">
													alert(\"Derguar me sukses .\");
													window.location = (\"index.php\")
													</script>";
								}

								else
								{
										echo "<script type = \"text/javascript\">
													alert(\"Deshtoi. Provoni Serish \");
													window.location = (\"contact.php\")
													</script>";
								}
						}
?>
	<?php
			include 'footer.php'
		?>



</body>
</html>
