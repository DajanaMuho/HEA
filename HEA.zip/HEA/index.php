<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtëpi</title>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>

	<div class="">
		<?php
			include 'header.php'
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila - Shtëpi Pushimi</h3>
			</section>
</div><!--  end hero section  -->


	<section class="listings">
		<div class="wrapper">
			<ul class="properties_list">
			<?php
						include 'includes/config.php';
						$sel = "SELECT * FROM shtepi WHERE status = 'Available'";
						$rs = $conn->query($sel);
						while($rws = $rs->fetch_assoc()){
			?>
				<li>
					<a href="bli_shtepi.php?id=<?php echo $rws['shtepi_id'] ?>">
						<img class="thumb" src="houses/<?php echo $rws['imazhe'];?>" width="300" height="200">
					</a>
					<span class="price">
					<?php echo $rws['cmim']." $";?>
					</span>
					<div class="property_details">
						<h1>
							<a href="bli_shtepi.php?id=<?php echo $rws['shtepi_id'] ?>">
							<?php 
							echo 'Pershkrim:'.$rws['pershkrim']; echo '<br> Cmim: '.$rws['cmim']."$";?></a>
						</h1>
					</div>
				</li>
			<?php
				}
			?>
			</ul>
		</div>
	</section>
	<?php
			include 'footer.php'
		?>
 
	
</body>
</html>