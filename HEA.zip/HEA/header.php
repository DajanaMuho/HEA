<?php
	session_start();
	error_reporting("E-NOTICE");
?>
<navbar>
			<div class="navbar">
				<nav>
				<a href="index.php"><IMG SRC="img/logo.png" style="float:left; margin-left 20px;" ALT="HEA" WIDTH=190 HEIGHT=100></a>
					<?php
						if(!$_SESSION['email'] && (!$_SESSION['pass'])){
					?>
					<ul>
						<li><a href="index.php">Faqja Kryesore</a></li>
						<li><a href="about.php">Rreth Nesh</a></li>
						<li><a href="contact.php">Kontakt</a></li>
					  <li><a href="account.php">Identifikohu</a></li>
					  <li><a href="login.php" style="">Admin</a></li>
					</ul>
					<?php
						} else{
					?>
							<ul>
								<li><a href="index.php">Faqja Kryesore</a></li>

								<li><a href="status.php">Shiko Profilin</a></li>
								<li><a href="modify_user.php">Modifiko Llogarinë</a></li>
								<li><a href="message_admin.php">Kontakto Adminin</a></li>
					<li>		
					<a href="admin/logout.php">Dilni</a>
					</li>
					</ul>
					<?php
						}
					?>
				</nav>
			</div>
</navbar>
