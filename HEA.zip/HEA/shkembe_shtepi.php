<!DOCTYPE html>
<html lang="en">
<head>
	<title>Shkëmbe Shtëpinë </title>
	
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

		
		<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila - Shtëpi Pushimi</h3>
			</section>
	</section><!--  end hero section  -->
	
	<section class="listings">
		<div class="wrapper">
			<ul class="properties_list">
			<?php
						include 'includes/config.php';
						$sel = "SELECT * FROM shtepi WHERE shtepi_id = '$_GET[id]'";
						$rs = $conn->query($sel);
						$rws = $rs->fetch_assoc();
			?>
				<li>
					<a href="shkembe_shtepi.php?id=<?php echo $rws['shtepi_id'] ?>">
						
					<img class="thumb" src="houses/<?php echo $rws['imazhe'];?>" width="300" height="200">
					</a>
					<span class="price"><?php echo $rws['cmim'];?></span>
					<div class="property_details">
						<h1>
							<a href="shkembe_shtepi.php?id=<?php echo $rws['shtepi_id'] ?>">
							<?php
							 echo 'Lloj  = '.$rws['lloj']; 
							  echo "<br>Cmim = ".$rws['cmim'];
							 echo "<br>Numer Dhome = ".$rws['numerDhome'];

							 $shtepi_id = $rws['shtepi_id'];
							  $lloj = $rws['lloj'];?></a><br>
							<a href="shkembe_shtepi.php?id=<?php echo $rws['shtepi_id']?>">Më Shumë Detaje </a>
						</h1>
						<h2>Pershkrim: <span class="property_size"><?php echo $rws['pershkrim'];?></span></h2>
					</div>
				</li>
				<?php
					if(!$_SESSION['email'] && (!$_SESSION['pass']))
					{
				?>
				<form method="post">
					<table>
						<tr>
							<td>Emër i Plotë :</td>
							<td><input type="text" name="fname" required></td>
						</tr>
						<tr>
							<td>Numër  Telefoni:</td>
							<td><input type="text" name="phone" required></td>
						</tr>
						<tr>
							<td>Adresë Email:</td>
							<td><input type="email" name="email" required></td>
						</tr>
						<tr>
							<td>Numër ID :</td>
							<td><input type="text" name="id_no" required></td>
						</tr>
						<tr>
							<td>Gjini:</td>
							<td>
								<select name="gjini">
									<option> --Zgjidh Gjininë-- </option>
									<option> Mashkull </option>
									<option> Femër </option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Adresë:</td>
							<td><input type="text" name="location" required></td>
						</tr>
						<tr>
							<td colspan="2" style="text-align:right"><input type="submit" name="save" value="Dorezo detaje"></td>
						</tr>
					</table>
				</form>
				<?php
					} else
						{
							?>
								<section class="listings">
									<div class="wrapper">
										<ul class="properties_list">
											<h3 style="text-decoration: underline">Bëj pagesën këtu </h3>
											<h5>Banka Kombetare Tregtare,BKT</h5>
											<h5>Bulevardi 'Zhan Dark',Tirane,Shqiperi</h5>
											<h5>SWIFT Code: ALBUUS33</h5><br>
											<h3 style="text-decoration: underline">Për kredi në: </h3>
											<h5>Emri i marrësit</h5>
											<h5>Marrësi numrin e llogarisë së BKT  </h5>
											<h2 style="text-decoration: underline">Pasi pagesa të konfirmohet do ju kontaktojme ne.</h2>
										</ul>
									</div>
								</section>
							<?php
						}
				?>
				<?php
						if(isset($_POST['save'])){
							include 'includes/config.php';
							$fname = $_POST['fname'];
							$id_no = md5($_POST['password']);
							$gender = $_POST['gender'];
							$email = $_POST['email'];
							$phone = $_POST['phone'];
							$location = $_POST['location'];
							
							$qry = "INSERT INTO client (fname,password,gender,email,phone,location)
							VALUES('$fname','$id_no','$gender','$email','$phone','$location')";
							$result = $conn->query($qry);
							if($result == TRUE){
								echo "<script type = \"text/javascript\">
											alert(\"Me sukses ,kaloni te pagesa.\")
											</script>";
											//nk suportojme pjesen e pageses
							} else{
								echo "<script type = \"text/javascript\">
											alert(\"Dështoi. Provoni sërish \");
											</script>";
							}
						}
					  ?>
			</ul>
		</div>
	</section>

	
	<?php
			include 'footer.php'
		?>
</body>
</html>