<footer>
		<div class="wrapper footer">
			<ul>
				<li class="links">
					<ul>

						<li style="font-family:lato-bold;">KOMPANIA  JONË</li>
						<li><a href="about.php">Rreth nesh</a></li>
						<li><a href="#">Kushte</a></li>
						<li><a href="#">Politikat</a></li>
						<li><a href="contact.php">Kontakt</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li style="font-family:lato-bold;">LLOJET E SHTËPIVE</li>
						<li><a href="#">Apartament</a></li>
						<li><a href="#">Vila</a></li>
						<li><a href="#">Shtëpi Pushimi</a></li>
						<li><a href="#">Të tjera.</a></li>
					</ul>
				</li>

				<li class="about" style="font-family:lato-bold;">NA KONTAKTONI
					<ul>
						<li><a href="#" class="facebook" target="_blank"></a></li>
						<li><a href="#" class="twitter" target="_blank"></a></li>
						<li><a href="#" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright &copy; <?php echo date("Y")?>  HEA
		</div>
	</footer><!--  end footer  -->
