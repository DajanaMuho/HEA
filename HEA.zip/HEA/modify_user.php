<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi</title>
	
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila - Shtëpi Pushimi</h3>
			</section>
	</section>



	<section class="listings">
		<div class="wrapper">
			
				<h3>Modifiko</h3>
				<form method="Post">
					<table>
						<tr>
							<td>Emri Mbiemri:</td>
							<td><input type="text" name="fname"></td>
						</tr>
						<tr>
							<td>Numri i Telefonit:</td>
							<td><input type="text" name="phone"></td>
						</tr>
						<tr>
							<td>Adresë emaili:</td>
							<td><input type="email" name="email"></td>
						</tr>

						<tr>
							<td>Password:</td>
							<td><input type="password" name="id_no1"></td>
						</tr>

						<tr>
							<td>Konfirmo Password:</td>
							<td><input type="password" name="id_no2"></td>
						</tr>

						<tr>
							<td>Gjinia:</td>
							<td>
								<select name="gender">
									<option> --Zgjidh Gjininë-- </option>
									<option> Mashkull </option>
									<option> Femër </option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Vendndodhja:</td>
							<td><input type="text" name="location"></td>
						</tr>
						<tr>
							<td colspan="2" style="text-align:right"><input type="submit" name="save" value="Dorezo"></td>
						</tr>
					</table>
					<p id = "password_match"></p>
				</form>
				<?php
					
					if($_POST['id_no1'] == $_POST['id_no2'])
					{
						if(isset($_POST['save']))
						{
							include 'includes/config.php';
							{
								$mail = $_SESSION['email'];

								
								$fname = strip_tags($_POST['fname']);
								$id_no = strip_tags($_POST['id_no1']);
								$hash = password_hash($id_no, PASSWORD_BCRYPT);
								$gender = $_POST['gender'];
								$email = strip_tags($_POST['email']);
								$phone = strip_tags($_POST['phone']);
								$location = strip_tags($_POST['location']);
									
								$qry = "UPDATE client SET fname = '$fname', password = '$hash', gender = '$gender', email ='$email' , phone = '$phone', location = '$location', status = 'Available' WHERE email = '$mail'";
								$result = $conn->query($qry);
								if($result == TRUE)
								{
									echo "<script type = \"text/javascript\">
													alert(\"Modifikimi u krye me sukses.\");
													window.location = (\"account.php\")
													</script>";
								} 

								else
								{
									echo "<script type = \"text/javascript\">
													alert(\"Modifikimi dështoi. Provo sërish\");
													window.location = (\"index.php\")
													</script>";
								}
								}
							}
							
						}
						
					

					else
					{
						$_POST['save'] = false;
						echo "<script type = \"text/javascript\">
											alert(\"Passwordet nuk përputhen. Provo sërish.\");
											window.location = (\"modify_user.php\")
											</script>";
					}
						
				?>

			</ul>
		</div>
	</section>

	
	<?php
			include 'footer.php'
		?>
	
	
</body>
</html>