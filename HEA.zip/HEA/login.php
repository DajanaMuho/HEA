<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi</title>


	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartamente - Vila - Shtëpi pushimi</h3>
			</section>
	</section>


	<section class="">
		<div class="">
		<div id="fom">
			<form method="post">
			<h3 style="text-align:center; color: #000099; font-weight:bold;">
			Identifikimi i administratorëve</h3>
				<table height="100" align="center">
					<tr>
						<td>Username :</td>
						<td><input type="text" name="uname" placeholder="Vendos Username" required></td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><input type="password" name="pass" placeholder="Vendos Password" required></td>
					</tr>
					<tr>
						<td style="text-align:right;"><input type="submit" name="login" value="Identifikohu"></td>
						<!-- <td style="text-align:right;"><a href="signup.php">Regjistrohu </a></td> -->
					</tr>
				</table>
			</form>
			<?php
				if(isset($_POST['login'])){
					include 'includes/config.php';

					$uname = $_POST['uname'];
					$pass = $_POST['pass'];

					$query = "SELECT * FROM admin WHERE uname = '$uname' AND pass = '$pass'";
					$rs = $conn->query($query);
					$num = $rs->num_rows;

					$rows = $rs->fetch_assoc();
					if($num > 0){
						session_start();
						$_SESSION['uname'] = $rows['uname'];
						$_SESSION['pass'] = $rows['pass'];

						echo "<script type = \"text/javascript\">
									alert(\"Identifikimi u krye me  sukses.................\");
									window.location = (\"admin/add_home.php\")
									</script>";
					} else{
						echo "<script type = \"text/javascript\">
									alert(\"Identifikimi dështoi. Provo sërish................\");
									window.location = (\"login.php\")
									</script>";
					}
				}
			?>

	</section>

	<?php
			include 'footer.php'
		?>


</body>
</html>
