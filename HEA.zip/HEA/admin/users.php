<?php
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "";
	$db_name = "shtepite";

	try
	{
		$DB_con = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	
	catch(PDOException $exception)
	{
		echo $exception->getMessage();
	}

	include_once 'class.paging3.php';
	$paginate = new paginate($DB_con);
?>

<!DOCTYPE html>
<html>
<head>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Bli Shtepi</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


	<script type="text/javascript">
		function User_detail(id){
			{
				window.location.href ='detail_user.php?id='+id;
			}
		}
	</script>

	<script src="../js/sorttable.js"></script>

</head>
<body>

<div id="header">
<?php
			include 'headeradmin.php';
		?>
	<div class="shell">
		
		
		</div>
	</div>
</div>

<div id="container">
	<div class="shell">
		
		<div class="small-nav">
			<a href="index.php">Panel Menuje</a>
			<span>&gt;</span>
		Menaxhim i klienteve
		</div>
		
		<br />
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<div id="content">
				
				<div class="box">
					
					<div class="box-head">
						<h2 class="left">Menaxhim i klienteve</h2>
					</div>
					
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0" id = "admin_table" class="sortable">
							<tr>
								<th>Emer Klienti</th>
								<th>Numer Telefoni</th>
								<th>Email i Klienti</th>
								<th width="110"></th>
							</tr>
							
							<tr>
								<?php 
						        $query = "SELECT * FROM client";       
								$records_per_page=3;
								$newquery = $paginate->paging($query,$records_per_page);
								$paginate->dataview($newquery);	
								?>
							</tr>
						</table>  
    <br /></td>
    <div><?php $paginate->paginglink($query,$records_per_page); ?></div>
    <td width="160" valign="top"><?php include_once "right_AD_template.php"; ?></td>
  </tr>

<?php include_once "footer_template.php"; ?>	
						</div>
						
						
					</div>
					<h2><input type="submit" onclick="window.print()" value="Printo" /></h2>
					
				</div>
				

			</div>
			<div class="cl">&nbsp;</div>			
		</div>
		
	</div>
</div>



<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - HEA</span>
	</div>
</div>
	
</body>
</html>