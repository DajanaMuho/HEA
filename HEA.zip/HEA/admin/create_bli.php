<?php

include '../includes/config.php';
?>



<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Bli Shtepi</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<script type="text/javascript">
		function sureToApprove(id){
			if(confirm("A jeni te sigurt qe doni ta aprovoni kete kerkese?")){
				window.location.href ='approve.php?id='+id;
			}
		}
	</script>
</head>
<body>
<!-- Header -->

		<?php
			include 'headeradmin.php';
		?>


<div id="container">
	<div class="shell">

		<div class="small-nav">
			<a href="index.php">Panel Menuje</a>
			<span>&gt;</span>
			Historia e Blerjeve
		</div>

		<br />

		<div id="main">
			<div class="cl">&nbsp;</div>
			<div id="content">
				<div class="box">
					<div class="box-head">
						<h2 class="left">Shto nje kontrate te re </h2>
					</div>

					<form action="" method="POST" enctype="multipart/form-data">

						<div class="form">
								<p>
									<label>Emer i klientit  <span>(Required Field)</label>
									<?php
									$sql = "SELECT * FROM client";
									$result = $conn->query($sql);
									echo "<select name='clientname'>";
									while ($row = $result->fetch_assoc())
									{
										echo "<option value='".$row['fname']."'>".$row['fname']."</option>";

									}

									echo "</select>";
									?>
								</p>
								<p>
									<label>Shtepi<span>(Required Field)</span></label>
									<?php
									$sql = "SELECT *  FROM shtepi";//[po e bem me distinct vec 3 id merren]
									$result = $conn->query($sql);
									echo "<select name='lloj'>";
									while ($row = $result->fetch_assoc())
									{
										echo "<option value='".$row['shtepi_id']."'>".$row['shtepi_id']."</option>";

									}

									echo "</select>";
									?>
								</p>
						<div class="buttons">
							<input type="submit" class="button" value="Submit" name="send" />
						</div>

					</form>
			<?php
			if(isset($_POST['send']))
			{
				$shtepi_lloj = $_POST['lloj'];
				$client_name = $_POST['clientname'];

				$sql = "SELECT * FROM client WHERE fname = '$client_name'";
				$result = $conn->query($sql);
				$row = $result->fetch_assoc();
				$client_id = $row['client_id'];


				$sql = "SELECT * FROM shtepi WHERE lloj = '$shtepi_lloj'";
				$result = $conn->query($sql);
				$row = $result->fetch_assoc();
				$shtepi_id = $row['shtepi_id'];
				$cmim = $row['cmim'];


				$data = date("Y.m.d");

				$qr = "INSERT INTO bli (client_name, client_id, lloj, shtepi_id, status, data_fillimit, cmim)
				 VALUES ('$client_name','$client_id', '$shtepi_lloj', '$shtepi_id', 'Approved', '$data', '$cmim')";
				$res = $conn->query($qr);


				if($res === TRUE)
				{
					echo "<script type = \"text/javascript\"> alert(\"Kontrata u krijua me sukses\")
						 </script>";
					

				}

			}
	?>
		</span>
		</label>
		</p>
		</div>
		</form>

		</div>


<td width="160" valign="top"><?php include_once "right_AD_template.php"; ?></td>

				</div>
			</div>
			<div class="cl">&nbsp;</div>
		</div>

	</div>
</div>



<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - HEA</span>
	</div>
</div>


</body>
</html>
