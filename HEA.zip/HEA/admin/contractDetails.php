<?php
	include '../includes/config.php';
	$id = $_REQUEST['id'];
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Bli Shtepi</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>

		<?php
			include 'headeradmin.php';
		?>
		</div>

<div id="container">
	<div class="shell">

		<div class="small-nav">
			<a href="index.php">Panel Menuje</a>
			<span>&gt;</span>
			Modifiko Kontraten
		</div>

		<br />

		<div id="main">
			<div class="cl">&nbsp;</div>

			<div id="content">

				<div class="box">
					<div class="box-head">
						<h2>Modifiko shtepine</h2>
					</div>

					<form action="" method="Post" enctype="multipart/form-data">
						<div class="form">
								<p>
									<label>Mbyll kontraten</label><br>
								</p>
						</div>

						<div class="buttons">
							<input type="submit" class="button" value="Submit" name="send" />
						</div>

					</form>

					<?php
					if(isset($_POST['send']))
					{
						$data = date("Y.m.d");
						$sql = "UPDATE bli SET status = 'Closed', data_mbarimit = '$data' WHERE bli_id = '$id'";
						$res = $conn->query($sql);
						echo $id;
						if($res === TRUE)
						{
							echo "<script type = \"text/javascript\">
											alert(\"Kontrata u editua me sukses\");
											window.location = (\"add_home.php\")
											</script>";

						}
					}

					?>
				</div>

			</div>
			<div class="cl">&nbsp;</div>
		</div>
	</div>
</div>

<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - HEA</span>
	</div>
</div>

</body>
</html>
