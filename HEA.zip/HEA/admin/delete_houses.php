<?php
	include '../includes/config.php';
	$cid = $_REQUEST['id'];
	$query = "DELETE FROM shtepi WHERE shtepi_id = '$cid'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"U fshi me sukses\");
					window.location = (\"add_home.php\")
				</script>";
	}
?>
