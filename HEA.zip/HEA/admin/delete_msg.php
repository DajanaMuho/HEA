<?php
	include '../includes/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM mesazhe WHERE mesazh_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Mesazhi u fshi me sukses \");
					window.location = (\"index.php\")
				</script>";
	}
?>
