<?php
	include '../includes/config.php';
	$id = $_REQUEST['id'];
	$query = "DELETE FROM bli WHERE bli_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Kontrata  u fshi me sukses\");
					window.location = (\"add_home.php\")
				</script>";
	}
?>
