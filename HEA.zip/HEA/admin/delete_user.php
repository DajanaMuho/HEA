<?php
	include '../includes/config.php';
	$cid = $_REQUEST['id'];
	$query = "DELETE FROM client WHERE client_id = '$cid'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Klienti u fshi me sukses\");
					window.location = (\"index.php\")
				</script>";
	}
?>
