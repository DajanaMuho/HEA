
<?php
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "";
	$db_name = "shtepite";

	try
	{
		$DB_con = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}

	catch(PDOException $exception)
	{
		echo $exception->getMessage();
	}

	include_once 'class.paging4.php';
	$paginate = new paginate($DB_con);
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Bli Shtepi</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />



</head>
<body>
<!-- Header -->
		<?php
			include 'headeradmin.php';
		?>
		</div>
		<!-- End Main Nav -->


<div id="container">
	<div class="shell">

		<div class="small-nav">
			<a href="index.php">Panel Menuje</a>
			<span>&gt;</span>
			Mesazhi i klientit
		</div>

		<br />

		<div id="main">
			<div class="cl">&nbsp;</div>

			<div id="content">

				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Mesazhi i klientit</h2>

					</div>

					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0" class="sortable">
							<tr>
								<th>Permbajtja e mesazhit</th>
								<th>Klienti</th>
								<th>Data</th>
								<th></th>
							</tr>
							<tr>
							<?php

						        $query = "SELECT * FROM mesazhe";
								$records_per_page=3;
								$newquery = $paginate->paging($query,$records_per_page);
								$paginate->dataview($newquery);

							?>
							</tr>
						</table>
					</div>
					<div>
					<?php $paginate->paginglink($query,$records_per_page); ?></div>
				</div>
				<!-- End Box -->
<h2><input type="submit" onclick="window.print()" value="Printo" /></h2>
			</div>
			<!-- End Content -->

			<!-- Sidebar -->
			<div id="sidebar">

				<!-- Box -->



					</div>
				</div>
				<!-- End Box -->
			</div>
			<!-- End Sidebar -->

			<div class="cl">&nbsp;</div>
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->

<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - HEA</span>
	</div>
</div>
<!-- End Footer -->

</body>
</html>
