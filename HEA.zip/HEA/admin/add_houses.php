<?php	include '../includes/config.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Bli Shtepi</title>

	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>
	<?php
		include 'headeradmin.php';
	?>
<div id="header">
	<div class="shell">
		
		
		</div>
	</div>
</div>

<div id="container">
	<div class="shell">
		
		<div class="small-nav">
			<a href="index.php">Panel Menuje</a>
			<span>&gt;</span>
			Shto Shtëpi Të Re
		</div>
		
		<br />
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<div id="content">
				
				<div class="box">
					<div class="box-head">
						<h2>Shto Shtëpi Të Re</h2>
					</div>
					
					<form action="" method="post" enctype="multipart/form-data">
						
						<div class="form">
								<p>
									<span class="req">max 50 simbole</span>
									<label> Lloj  <span>(Required Field)</span></label>
									<input type="text" class="field size1" name="lloj" required />
								</p>	
								<p>
									<span class="req">max 150 simbole</span>
									<label >Pershkrim <span>(Required Field)</span></label>
									<input type="text" class="field size1" name="pershkrim" required />
								</p>
								<p>
									<span class="req">max 2 simbole</span>
									<label >Numer dhomash <span>(Required Field)</span></label>
									<input type="text" class="field size1" name="nr_dhome" required />
								</p>
								<p>
									<span class="req">max 20 symbols</span>
									<label>Cmim <span>(Required Field)</span></label>
									<input type="text" class="field size1" name="cmim" required />
								</p>
								<p>
									<span class="req">Imazhet</span>
									<label>Imazhet e Shtëpisë <span>(Required Field)</span></label>
									<input type="file" class="field size1" name="image" required />
								</p>
						
								<p>
									<span class="req">max 5 symbols</span>
									<label>Siperfaqe<span>(Required Field)</span></label>
									<input type="text" class="field size1" name="siperfaqe" required />
								</p>

								<p>
									<span class="req">max 20 symbols</span>
									<label>Adrese<span>(Required Field)</span></label>
									<input type="text" class="field size1" name="location" required />
								</p>
							
						</div>
						
						<div class="buttons">
							<input type="submit" class="button" value="Submit" name="send" />
						</div>
						
					</form>
					<?php
							if(isset($_POST['send'])){
								
								$home_path = "../houses/";
								$home_path = $home_path . basename ($_FILES["image"]["name"]);
								if(move_uploaded_file($_FILES["image"]["tmp_name"], $home_path)){
								
								$image = basename($_FILES["image"]["name"]);
							
								$lloj= $_POST['lloj'];
								$pershkrim = $_POST['pershkrim'];
								$nr_dhome=$_POST['nr_dhome'];
								$cmim = $_POST['cmim'];
								$siperfaqe = $_POST['siperfaqe'];
							     $location = $_POST['location'];
								
								$qr = "INSERT INTO shtepi (lloj,pershkrim,numerDhome,cmim,imazhe,siperfaqe,adrese,status) 
													VALUES ('$lloj','$pershkrim','$nr_dhome','$cmim','$image','$siperfaqe','$location','Available')";
								$res = $conn->query($qr);
								if($res === TRUE){
									echo "<script type = \"text/javascript\">
											alert(\"Shtepia u shtua me sukses\");
											window.location = (\"add_home.php\")
											</script>";
									}
									else {
										echo "<script type = \"text/javascript\">
										alert(\"Shtepia nuk u shtua \");
										window.location = (\"add_houses.php\")
										</script>";
									}
								}
								else "<script type = \"text/javascript\">
								alert(\"Failed\");
								window.location = (\"add_houses.php\")
								</script>";'';
							}
						?>
				</div>

			</div>
			
			<div id="sidebar">
				
				<div class="box">
					
					<div class="box-head">
						<h2>Menaxhimi</h2>
					</div>
					
					<div class="box-content">
						<a href="add_home.php" class="add-button"><span>Shikoni Shtëpitë</span></a>
						<div class="cl">&nbsp;</div>
						

						
					</div>
				</div>
			</div>
			
			<div class="cl">&nbsp;</div>			
		</div>
	</div>
</div>

<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - HEA</span>
	</div>
</div>
	
</body>
</html>