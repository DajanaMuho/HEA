<?php
	error_reporting("E-NOTICE");
?>
<?php
	session_start();
	if(!$_SESSION['uname'] && (!$_SESSION['pass'])){
		header("location: ../login.php");
	}
?>
<navbar>
	<div class="navbar">
		<nav>
			<a href="index.php"><IMG SRC="css/images/logo.png" style="float:left; margin-left 20px;" ALT="HEA" WIDTH=190 HEIGHT=100></a>
			<ul>
				<li><a href="index.php"><span>Mesazhet</span></a></li>
				<li><a href="add_home.php"><span>Menaxhimi i Shtëpive</span></a></li>
				<li><a href="client_requests.php"><span>Historiku i Blerjeve</span></a></li>
				<li><a href="users.php"><span>Menaxhimi i Klientëve</span></a></li>
				<li><a href="logout.php">Dil</a></li>
			</ul>
		</nav>
	</div>
</navbar>
