<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi</title>


	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartamente - Vila - Shtëpi pushimi</h3>
			</section>
	</section>


	<section class="">
		<div class="">
		<div id="fom">
			<form method="post">
			<h3 style="text-align:center; color: #000099; font-weight:bold;">
			Identifikimi i përdoruesve</h3>
				<table height="100" align="center">
					<tr>
						<td style="font-family:sans-serif;">Adrese Email :</td>
						<td><input type="email" name="email" placeholder="Vendos Adrese Email" required></td>
					</tr>
					<tr>
						<td style="font-family:sans-serif;">Password:</td>
						<td><input type="password" name="pass" placeholder="Vendos Password" required></td>
					</tr>
					<tr>
						<td><input type="submit" name="log" value="Login" style="background-color: #9b3434; border: none; color: white; padding: 10px 32px; text-align: center; text-decoration: none; display: inline-block;"></td>
						<td style="text-align:right; text-decoration: none;"><a href="signup.php">Regjistrohu </a></td>
					</tr>
				</table>
			</form>
			<?php

				if(isset($_POST['log'])){
					include 'includes/config.php';

					$uname = strip_tags($_POST['email']);

					$pass = strip_tags($_POST['pass']);

					$qy = "SELECT * FROM client WHERE email = '$uname'";

					$log = $conn->query($qy);
					$row = $log->fetch_assoc();

					$hash = $row['password'];

					if(password_verify($pass, $hash))
					{
						session_start();
						$_SESSION['email'] = $row['email'];
						$_SESSION['password'] = $row['password'];
						$_SESSION['clientid'] = $row['client_id'];
						$_SESSION['clientname'] = $row['fname'];

						echo "<script type = \"text/javascript\">
									alert(\"Identifikimi u krye me sukses\");
									window.location = (\"index.php\")
									</script>";
					}


					else{
						echo "<script type = \"text/javascript\">
									alert(\"Idetifikimi dështoi. Provo sërish \");
									window.location = (\"account.php\")
									</script>";
					}
				}
			?>

	</section><!--  end search section  -->

	<?php
			include 'footer.php'
		?>


</body>
</html>
