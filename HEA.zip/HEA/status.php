<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi</title>


	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

	<style type="text/css">
	table {
	  border-spacing: 0.5rem;
	   margin-left: auto;
	    margin-right: auto;
	}
	td {
	  padding: 0.5rem;
	}

	td:nth-child(1) { background: hsl(140, 50%, 50%); }
	td:nth-child(2) { background: hsl(110, 60%, 50%); }
	td:nth-child(3) { background: hsl(270, 70%, 50%); }
	td:nth-child(4) { background: hsl(10, 80%, 50%); }
	td:nth-child(5) { background: hsl(190, 90%, 50%); }
	td:nth-child(6) { background: hsl(200, 99%, 50%); }


	</style>

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila - Shtëpi Pushimi</h3>
			</section>
	</section>


	<section class="listings">
		<div class="">
		<h2 style="text-align:center; text-decoration:underline">Statusi i Blerjeve Tuaja</h2>
			<ul class="properties_list">
			<?php
						include 'includes/config.php';
						$sel = "SELECT * FROM client WHERE email = '$_SESSION[email]'";
						$rs = $conn->query($sel);
						$rws = $rs->fetch_assoc();
						$client_id = $rws['client_id'];

			?>
				<li>
						<h6><span style="font-size:25px; color: #FF0000">Historiku i Blerjeve Tuaja:</span></h6>


			<div  class="caption">
			<table width="100%" id = "client_table" class="table" align="right" >
				<th style="font-family:lato-regular;">Lloj i shtëpisë</th>
				<th style="font-family:lato-regular;">Data e Blerjes</th>
				<th style="font-family:lato-regular;">Çmimi</th>
				<th style="font-family:lato-regular;">Statusi</th>

				<?php
						include 'includes/config.php';
						$sel = "SELECT * FROM bli WHERE client_id = '$client_id'";
						$rs = $conn->query($sel);


		while ( $rws = $rs->fetch_assoc())
	{
				?>

				<tr>
				<td style="font-family:lato-regular;"><?php echo $rws['lloj'];?></td>
				<td style="font-family:lato-regular;"><?php echo $rws['data_fillimit'];?></td>
				<td style="font-family:lato-regular;"><?php echo $rws['cmim']. "  $";?></td>
				<td style="font-family:lato-regular;"><?php echo $rws['status']; ?></td>
				</tr>
				<?php
				}
			?>
			</table>

			</div>
				</li>
			</ul>
		</div>
	</section>

	<?php
			include 'footer.php'
		?>

</body>
</html>
