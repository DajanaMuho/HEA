<!DOCTYPE html>
<html lang="en">
<head>
 <title>Bli Shtepi</title>
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	<style type="text/css">
		.status{
			font-size: 20px;
		}
		.txt{
			width: 600px;
			height: 200px;
		}
	</style>

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila - Shtëpi Pushimi</h3>
			</section>
	</section><!--  end hero section  -->


	<section class="listings">
		<div class="wrapper">
		<h2 style="text-align: center; color:#CC0000">Faleminderit që na kontaktuat. Ne do ju përgjigjemi shumë shpejt.</h2>
			<ul class="properties_list">
			
			</ul>
		</div>
	</section>	<!--  end listing section  -->


	<?php
			include 'footer.php'
		?>
	
</body>
</html>