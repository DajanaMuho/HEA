<!DOCTYPE html>
<html lang="en">
<head>
	<title>Rreth Nesh</title>


	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

	<section>
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">Rreth Nesh</h2>
				<h3 class="properties" style="text-align: center">Apartamente - Vila - Shtëpi pushimi</h3>
			</section>

<div class="wrapper">
				<h4>Kompania HEA në Shqipëri, qëllimi ynë kryesor është që të bëjmë më të lehtë për të gjithë të blejnë ose të shesin pronën e tyre.
Ne përdorim internetin për të sjellë zgjedhjet për ju.
 Nëse banoni në Shqipëri apo jo, ju mund të shikoni listën tonë të plotë të pronave online, me fotografi dhe informacione të detajuara.
 Pronat tona gjendet pergjatë gjithë shqipërise në zona të destinuara për zhvillimin e turizmit apo vendet komerciale, në vila, apartamente etj.
Ne bashkpunojmë me Bankat më të mëdha ne Shiqipëri te cilat do bëjnë  shumë të thjeshtë dhe të sigurt transaksionin e blerjes.</h4>
</div>
</section>
	<?php
			include 'footer.php'
		?>
</body>
</html>
