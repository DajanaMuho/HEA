<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtëpi</title>
	<meta charset="utf-8">	
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
	
	<style type="text/css">
		.status{
			font-size: 20px;
		}
		.txt{
			width: 600px;
			height: 200px;
		}
	</style>

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

		<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartament - Vila  - Shtëpi Pushimi</h3>
			</section>
	</section>

	<section class="listings">
		<div class="wrapper">
		<h2 style="text-decoration:underline">Shkruaj këtu Adminit </h2>
			<ul class="properties_list">
			<form method="post">
				<table>
					<tr>
						<td style="color: #003300; font-weight: bold; font-size: 24px; font-family: lato-regular;">Vendos mesazhin tënd këtu </td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>
							<textarea name="message" placeholder="Mesazhi" class="txt"></textarea>
						</td>
					</tr>
					<tr>
						<td><input type="submit" name="send" value="Dergo Mesazhin"></td>
					</tr>
				</table>
			</form>

				<?php
					if(isset($_POST['send'])){
						include 'includes/config.php';
						$message = $_POST['message'];
						$date = date("Y-m-d");
						$qry = "INSERT INTO mesazhe (mesazh, klient, time)
							VALUES('$message','$_SESSION[email]','$date')";
							$result = $conn->query($qry);
							if($result === TRUE)
							{
								echo "<script type = \"text/javascript\">
											alert(\"Mesazhi u dergua me sukses.\");
											window.location = (\"success.php\")
											</script>";
							} else{
								echo "<script type = \"text/javascript\">
											alert(\"Mesazhi nuk u dergua. Provoni sërish\");
											window.location = (\"message_admin.php\")
											</script>";
							}
					}
				?>
			</ul>
		</div>
	</section>	

	<?php
			include 'footer.php';
		?>
	
</body>
</html>