<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
	$query = "UPDATE client SET status = 'Approved' WHERE client_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo 'Kerkesa u pranua me sukses';
	?>
		<meta content="4; client_requests.php" http-equiv="refresh" />
	<?php
	}
?>
