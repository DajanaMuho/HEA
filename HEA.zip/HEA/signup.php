<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bli Shtepi | Regjistrimi</title>

	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>

	<section class="">
		<?php
			include 'header.php';
		?>

			<section class="caption">
				<h2 class="caption" style="text-align: center">GJENI SHTËPINË E ËNDËRRAVE TUAJA</h2>
				<h3 class="properties" style="text-align: center">Apartamente - Vila - Shtëpi Pushimi</h3>
			</section>
	</section>

	<section class="listings">
		<div class="wrapper">
				<h3>Regjistrohuni Këtu</h3>
				<form method="Post">
					<table>
						<tr>
							<td style="font-family: sans-serif;">Emër i plotë :</td>
							<td><input type="text" name="fname" required></td>
						</tr>
						<tr>
							<td style="font-family: sans-serif;"> Numri i telefonit:</td>
							<td><input type="text" name="phone" required></td>
						</tr>
						<tr>
							<td style="font-family: sans-serif;">Adresa Email :</td>
							<td><input type="email" name="email" required></td>
						</tr>

						<tr>
							<td style="font-family: sans-serif;">Password:</td>
							<td><input type="password" name="id_no1" required></td>
						</tr>

						<tr>
							<td style="font-family: sans-serif;">Konfirmo Password:</td>
							<td><input type="password" name="id_no2" required></td>
						</tr>

						<tr>
							<td style="font-family: sans-serif;">Gjinia:</td>
							<td>
								<select name="gender">
									<option> --Zgjidh gjininë--  </option>
									<option> Mashkull </option>
									<option> Femër </option>
								</select>
							</td>
						</tr>
						<tr>
							<td style="font-family: sans-serif;">Adresa:</td>
							<td><input type="text" name="location" required></td>
						</tr>
						<tr>
							<td colspan="2" style="text-align:right"><input type="submit" name="save" value="Regjistrohu"></td>
						</tr>
					</table>
					<p id = "password_match"></p>
				</form>
				<?php
					if($_POST['id_no1'] == $_POST['id_no2'])
					{
						if(isset($_POST['save']))
						{
							include 'includes/config.php';
							{
								// $mail = $_POST['email'];
								// $qr = "SELECT count(email) FROM client WHERE email = '$mail'";
								// $result = $conn->query($qr);
								// $nr = $result->num_rows;
								// echo $nr;

								// if($nr == 0)
								// {
									$fname = strip_tags($_POST['fname']);
									$id_no = strip_tags($_POST['id_no1']);
									$hash = password_hash($id_no, PASSWORD_BCRYPT);
									$gender = $_POST['gender'];
									$email = strip_tags($_POST['email']);
									$phone = strip_tags($_POST['phone']);
									$location = strip_tags($_POST['location']);

									$qry = "INSERT INTO client (fname,password,gender,email,phone,location)
									VALUES('$fname','$hash','$gender','$email','$phone','$location')";
									$result = $conn->query($qry);
									if($result == TRUE)
									{
										echo "<script type = \"text/javascript\">
													alert(\"U regjistruat me sukses .\");
													window.location = (\"account.php\")
													</script>";
									}

									else
									{
										echo "<script type = \"text/javascript\">
													alert(\"Regjistrimi deshtoi . Provo Serish\");
													window.location = (\"signup.php\")
													</script>";
									}
								// }

								//  else
								//  {
								//  	echo "<script type = \"text/javascript\">
								//  					alert(\"Perdor email tjeter.\");
								//  					window.location = (\"signup.php\")
								//  					</script>";
								//  }
							}

						}

					}

					else
					{
						$_POST['save'] = false;
						echo "<script type = \"text/javascript\">
											alert(\"PASSOWRD nuk jane te njejte. Provoni perseri.\");
											window.location = (\"signup.php\")
											</script>";
					}

				?>

			</ul>
		</div>
		</section>
		<?php
			include 'footer.php'
		?>
	
</body>
</html>
